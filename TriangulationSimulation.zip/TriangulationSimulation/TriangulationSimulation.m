 clear all; close all;clc

 %Reference points/Microphone positions in grid
P37 =[	27	-1.30	2]'; %Reference to other microphones
P31 =[	20.693	-4.849	2]';
P102 =[	22.590	0.524	2]';
P43 =[	17.113	-3.003	2]';
%P208 =[	22.554	4.727	1.77]';
%P101 =[	22.447	-7.880	1.6]';


%True solution/position of sound source (Unknown)
N=[26.759	-1.342	2];


%distance = speed_of_sound*TDOA_for_each_sensor_microphone.
%Assuming the speed of sound = 344m/s
%To be replaced by distances calculated from time delay data.
s037=344*0; %Assuming Time Delay to P037 = 0.01seconds
s031=344*0.02036;%Assuming Time Delay to P031 = 0.02seconds
s0102=344*0.01327;%Assuming Time Delay to P102 =0.013seconds
s043=344*0.02855;%Assuming Time Delay to P043 = 0.02seconds

%s037=norm(P37-N);
%s031=norm(P31-N);
%s0102=norm(P102-N);
%s043=norm(P43-N);
%s0208=norm(P208-N);
%s0101=norm(P101-N);

%Distances
fprintf('\n  True distances \n');
Ssoll =    [s037  s031  s0102 s043];%   s0208  s0101];
disp(Ssoll);

%This part has to be done physically but so I had to just assume these distances
fprintf('\n Measured distances: \n');
S38=       [0 7.036 4.586 9.960];% 7.542   7.883];
disp(S38);

% corrected distances(Assuming there are no barriers so they are all 0)
fprintf('\n Corrected measured distances based on excess delay: \n');
S38= S38 - [ 0    0      0    0];   
P = [P37 P31 P102 P43];% P208 P101];
disp(S38);

fprintf('\n ---Trilateration: Direct solution --- \n');
S = S38;
W = diag(ones(1,length(S)));
[N1 N2] = Trilateration(P,S, W);
Nsol1 = N1(2:4,1);
disp([Nsol1])

fprintf('\n\n\n');

fprintf('\n ---Trilateration: Recursive least square--- \n');
Nmat0 = RecTrilateration(P,S,W);
Nmat = Nmat0(:,1:3);
fprintf('\n Recursive solutions \n');
disp(Nmat(2:4,:))
[n_mat m_mat]=size(Nmat);
for i1=1:m_mat
    Nn = Nmat(:,i1);
    Nn = Nn(2:4);
    [Sn(i1,:) , F(i1)] = distanzen(Nn,P,S);
    Diff(i1)= Nmat(1,i1) - (norm(Nn))^2;
end
[Fmin Imin] = min(F);
Nrec = Nmat(:,Imin);
fprintf('\n The solution which minimizes the error square sum \n');
Nrec = Nrec(2:4);
disp(Nrec);

Nrec_r = sign(real(Nrec)).*abs(Nrec);
[Sneu Fneu ] = distanzen(Nrec,P,S);
fprintf('\n Calculated distances (Distances to solution)\n');
disp(Sneu )
fprintf('\n Error norm\n');
disp(Fneu)


% Define the grid size (10m by 10m)
gridSize = 20;

% Create a figure
figure;
hold on;

% Plot Nrec in red
plot(Nrec(1), Nrec(2), 'ro', 'MarkerSize', 10);

% Plot N in green
plot(N(1), N(2), 'go', 'MarkerSize', 10);

% Plot reference points in blue
plot(P37(1), P37(2), 'bo', 'MarkerSize', 10);
plot(P31(1), P31(2), 'bo', 'MarkerSize', 10);
plot(P102(1), P102(2), 'bo', 'MarkerSize', 10);
plot(P43(1), P43(2), 'bo', 'MarkerSize', 10);
%plot(P208(1), P208(2), 'bo', 'MarkerSize', 10);
%plot(P101(1), P101(2), 'bo', 'MarkerSize', 10);

% Set axis limits to match the grid size
axis([-gridSize/2 gridSize/2 -gridSize/2 gridSize/2]);

% Add labels and a legend
xlabel('X-axis (cm)');
ylabel('Y-axis (cm)');
legend('Estimated Position', 'True Position', 'Reference Points/Microphones');

% Add a title
title('Triangulation Simulation');

% Hold off to stop adding additional elements to the plot
hold off;


